# O Caracter # marca uma linha de comentário
print("Aprendendo a usar comentário")

'''
Outra forma de fazer comentário, só que maior
múltiplas linhas 
'''