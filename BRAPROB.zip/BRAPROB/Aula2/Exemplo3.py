'''
Entrada de dados utilizando o comando input.
'''

login = input("Login: ")
senha = input("Senha: ")

print("O usuário informado foi: %s \nA senha digitada foi: %s" %(login, senha))