'''
Ler dois valores inteiros para as variáveis A e B e efetuar
a troca dos valores de forma que a variável A passe a possuir
o valor da variável B e a variável B passe a possuir o valor
da variável A. Apresentar os valores após a efetivação da troca.
'''
a = int(input("Entre com o valor de A: "))
b = int(input("Entre com o valor de B: "))
print("\nValor de A = ", a)
print("Valor de B = ", b)

print("\nSolução convencional")
aux = a
a = b
b = aux

print("Valor de A = ", a)
print("Valor de B = ", b)

print("-----------------------------")

print("Solução pytônica")
a, b = b, a
print("Valor de A = ", a)
print("Valor de B = ", b)

