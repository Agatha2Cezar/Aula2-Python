'''
Calcular as raízes de uma equação do 2º grau com os valores
das variáveis de entrada fornecidas pelo usuário
ax2 + bx + c = 0

onde x é uma incógnita que será calculada e os valores
de a, b e c são conhecidos, ou seja, coeficientes da equação que serão
fornecidos pelo usuário
'''

print("Calculando as raízes de uma equação de 2° grau\n")

a = float(input("Entre com o valor de A: "))
b = float(input("Entre com o valor de B: "))
c = float(input("Entre com o valor de C: "))

#Calculando as raízes da equação
delta = (b ** 2 - 4 * a * c)
x1 = (-b + delta ** (1/2)) / (2*a)
x2 = (-b - delta ** (1/2)) / (2*a)

print("\nO valor de x1 = {0}" .format(x1))
print("\nO valor de x2 = {0}" .format(x2))
'''
Outra forma de mostrar isso:
print("O valor de x1 = {0} e x2 = {1} " .format(x1,x2))
'''
enter = input("Pressione ENTER para encerrar ...")

