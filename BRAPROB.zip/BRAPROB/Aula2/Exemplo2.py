num_int = 5
num_dec = 7.3
val_str = "Análise de Sistemas"

'''
Podemos exibir as variáveis de três maneiras:
Primeira: Concatenando uma string com valor int
A string é concatenada ao valor int através da vírgula 
A vírgula, na verdade converte o valor int para string
'''

print("O valor inteiro é = ", num_int)

'''
Segundo: utilizando um marcador
O marcador %i indica que no local onde ele está
será exibido um valor do tipo int, por isso %i.
Em seguida devemos inserir a variável cujo conteúdo será
mostrado, no caso, num_int. Ela deverá estar acompanhada
do marcador % que indica o conteúdo da variável.
'''

print("O valor inteiro é = %i" %num_int)

'''
Terceiro: Convertendo a variável in através de um cast.
utiliza-se a função str() para converter um valor qualquer em string.
É necessário o sinal de adição + que fará a concatenação entre os dois tipos de dados.
'''

print("O valor inteiro é = " + str(num_int))


print("Concatenando variável Decimal: ", num_dec)
print("Concatenando variável Decimal: %.f" %num_dec)
print("Concatenando variável Decimal: %.2f" %num_dec)
print("Concatenando variável Decimal: " + str(num_dec))

#Variável do tipo string

print("Concatenando variável String: ", val_str)
print("Concatenando variável String: %s" %val_str)
print("Concatenando variável String: " + val_str)